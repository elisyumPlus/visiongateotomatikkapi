# Kepenk Sistemleri — Demo (Stok görsellerle)

Bu paket, sağlanan örnek görsel referansına yakın bir ana sayfa demo’sudur. Stok görseller kullanılarak hızlı bir önizleme oluşturulmuştur.

İçerik:
- index.html — Ana sayfa
- css/style.css — Derlenmiş stil dosyası
- scss/style.scss — Basit SCSS kaynak (örnek)
- js/main.js — Mobil menü, Teklif Al modal ve form mock

Nasıl çalıştırılır:
1. Tüm dosyaları aynı klasöre koyun (index.html kök dosya).
2. Tarayıcıda `index.html` dosyasını açın. (HTTP server gerekli değil, ama bazı tarayıcı güvenlikleri nedeniyle tercih ederseniz `npx http-server` veya benzeri bir küçük static server kullanabilirsiniz.)

Canlı yayın (opsiyonel):
- GitHub Pages: Yeni bir repo oluşturun, dosyaları push edin. Settings > Pages > Branch: main / docs klasörü seçerek yayınlayabilirsiniz.
- Netlify: Yeni site > "Drag & Drop" ile dizini yükleyip otomatik deploy alabilirsiniz.

Değiştirmek istediğiniz şeyler:
- Görselleri değiştirmek isterseniz `index.html` içinde product-card img src’larını yazdığınız görsellerle değiştirin.
- Telefon, e‑posta, marka adı gibi metinleri index.html içinde düzenleyin.
- Formu gerçek backend’e bağlamak isterseniz `js/main.js` içerisinde form submit kısmını backend POST isteği ile değiştiririm (PHP/Node/Netlify Forms vs).

İsterseniz ben bu demo’yu sizin için GitHub Pages’e deploy edebilirim. Bunun için şu bilgilerden birini verin:
- (Tercih 1) Bana repo sahibinin adını söyleyin — ben repository oluşturup dosyaları push edeyim (public repo).
- (Tercih 2) Kendi GitHub hesabınıza push etmemi isterseniz repo adı ve erişim izni verin (ben push için bir PR/dosyayı hazırlarım veya adımları gösteririm).

İleri adım:
- Canlı yayın istiyorsanız hangi yolu tercih ediyorsunuz? (GitHub Pages / Netlify / Benim oluşturmam)
- Veya dosyaları zip yapıp gönderip sizin açmanızı ister misiniz?
